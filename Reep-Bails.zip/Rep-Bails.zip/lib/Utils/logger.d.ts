declare const _default: import("pino").Logger<{
    timestamp: () => string;
}>;
export default _default;
